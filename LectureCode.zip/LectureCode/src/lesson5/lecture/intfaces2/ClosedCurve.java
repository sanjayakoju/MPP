package lesson5.lecture.intfaces2;

public interface ClosedCurve {
	public double computePerimeter();
}
