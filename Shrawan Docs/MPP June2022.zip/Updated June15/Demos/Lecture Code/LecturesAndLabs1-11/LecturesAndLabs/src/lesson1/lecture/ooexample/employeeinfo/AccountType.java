package lesson1.lecture.ooexample.employeeinfo;

public enum AccountType {
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}
