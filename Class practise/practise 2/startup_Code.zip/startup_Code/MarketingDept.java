package prob2;

public class MarketingDept {
	//implement
	
	public void applyForJob() {
		//not implemented
	}
}
