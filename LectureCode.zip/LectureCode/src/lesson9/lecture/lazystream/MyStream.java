package lesson9.lecture.lazystream;
import java.util.*;
public class MyStream {
	List list;
	public MyStream() {
		list = new ArrayList();
	}
}
