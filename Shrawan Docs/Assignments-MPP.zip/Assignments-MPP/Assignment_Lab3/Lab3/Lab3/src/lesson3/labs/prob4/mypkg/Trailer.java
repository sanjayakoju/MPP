package lesson3.labs.prob4.mypkg;

public class Trailer extends Property {
	
	public Trailer() {
		super();
	}
	
	@Override
	public double computeRent() {
		return 500;
	}

}
