package lesson3.lecture.inheritance0;

public class Superclass {
	protected void print(String s) {
		System.out.println(s);
	}
}
