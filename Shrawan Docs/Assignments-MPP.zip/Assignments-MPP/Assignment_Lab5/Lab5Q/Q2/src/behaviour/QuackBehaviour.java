package behaviour;

public interface QuackBehaviour {

    void quack();
}
