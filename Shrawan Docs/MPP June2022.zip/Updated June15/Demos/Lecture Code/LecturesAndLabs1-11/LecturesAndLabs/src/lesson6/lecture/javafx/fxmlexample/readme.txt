Example 1 - shows the basic FXML document for laying out components

Example 2 - shows how to handle events by assigning an id to
each event generating component, in the style of javascript

Example 3 - shows an alternative (better) way to handle events,
by injecting event-generating components into a Controller
class, responsible for event-handling code

Example 4 - shows how to add CSS styling to JavaFX application
that is created primarily with FXML