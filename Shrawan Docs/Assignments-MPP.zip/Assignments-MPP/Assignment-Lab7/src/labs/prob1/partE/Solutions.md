
1. If D is a Class and A, B, C are interfaces
    - D must have concrete implementation of the method()
2. If D is an interface
   - D must override and create default method in its interface (Java 8)