package lesson6.lecture.javafx.tables;

public class GuiConstants {
	public static final int SCENE_WIDTH = 500;
	public static final int SCENE_HEIGHT = 400;
	public static final int GRID_PANE_WIDTH = 250;
	public static final int PROD_DETAILS_GRID_WIDTH = 400;
	
	
}
