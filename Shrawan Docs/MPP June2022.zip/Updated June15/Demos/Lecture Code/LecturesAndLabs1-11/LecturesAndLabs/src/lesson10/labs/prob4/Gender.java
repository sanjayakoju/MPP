package lesson10.labs.prob4;

public enum Gender {
	M, F
}
