package labs.prob4.behaviour;

public class FlyWithWings implements FlyBehaviour{

}
