package lesson3.labs.prob4.mypkg;

public class Property {
	
	private Address address;
	
	Property(){
		
	}
	

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public double computeRent() {
		return 0;
	}
	
	

}
