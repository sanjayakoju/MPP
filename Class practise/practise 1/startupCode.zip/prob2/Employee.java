package prob2;

public class Employee {
	public double computeUpdatedBalanceSum() {
		//implement
		return 0.0;
	}
}
