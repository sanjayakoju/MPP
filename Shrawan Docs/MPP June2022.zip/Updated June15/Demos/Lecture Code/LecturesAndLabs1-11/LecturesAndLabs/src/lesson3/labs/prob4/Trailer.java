package lesson3.labs.prob4;

public class Trailer  {

	public double computeRent(){
		return 500;
	}
}
