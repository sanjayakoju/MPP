package labs.prob4.behaviour;

public class Quack implements QuackBehaviour {

}
