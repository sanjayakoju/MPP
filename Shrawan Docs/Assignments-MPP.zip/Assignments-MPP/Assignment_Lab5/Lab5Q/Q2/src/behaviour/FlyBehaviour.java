package behaviour;

public interface FlyBehaviour {

    void fly();
}
