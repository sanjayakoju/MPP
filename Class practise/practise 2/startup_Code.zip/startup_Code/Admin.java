package prob2;

public class Admin {
	//implement
	
}
