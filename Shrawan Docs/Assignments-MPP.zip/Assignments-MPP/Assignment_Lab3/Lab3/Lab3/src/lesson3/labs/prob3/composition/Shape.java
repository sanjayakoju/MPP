package lesson3.labs.prob3.composition;

public interface Shape {

	double computeArea(); 
}
