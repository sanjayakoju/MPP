package labs.prob2;

public interface ClosedCurve {	
	double computePerimeter();
}
