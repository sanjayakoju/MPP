Shows how interfaces can be used for polymorphism.
These files do it the OO way

See lesson7.labssolns.prob2 for further refinements