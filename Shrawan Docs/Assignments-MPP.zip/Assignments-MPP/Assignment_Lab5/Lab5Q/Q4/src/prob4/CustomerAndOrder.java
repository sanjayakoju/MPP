package prob4;

public interface CustomerAndOrder {

    Customer getCustomer();

    Order getOrder();
}
