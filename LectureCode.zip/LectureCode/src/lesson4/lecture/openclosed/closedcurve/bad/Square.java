package lesson4.lecture.openclosed.closedcurve.bad;

public final class Square  {
	private final double side;
	
	public Square(double side){
		this.side = side;
		
	}
	public double computeArea() {
		return side * side;
	}


}
