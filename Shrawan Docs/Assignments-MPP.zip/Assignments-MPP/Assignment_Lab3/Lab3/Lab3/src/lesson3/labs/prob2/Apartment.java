package lesson3.labs.prob2;

public class Apartment {
	
	private double rent;
	
	Apartment(double rent) {
		this.rent = rent;
	}

	public double getRent() {
		return rent;
	}
	
	

}
