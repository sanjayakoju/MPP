package prob12;

public class Problem12Main {

    public static void main(String[] args) {

        System.out.println(MySingletonLazy.getInstance());
    }
}
