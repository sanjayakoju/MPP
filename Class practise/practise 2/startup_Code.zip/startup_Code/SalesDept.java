package prob2;

public class SalesDept {
	//implement
	
	
	public void requestMarketingMaterials() {
		//not implemented
	}
}
