package figures;

public interface FigureShape {

    double computeArea();
}
