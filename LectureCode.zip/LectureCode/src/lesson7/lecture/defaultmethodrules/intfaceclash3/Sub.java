package lesson7.lecture.defaultmethodrules.intfaceclash3;

public interface Sub {

}
